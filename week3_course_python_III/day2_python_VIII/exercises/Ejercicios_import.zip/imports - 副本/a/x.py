def f1x():
    print("hola")
def f2x():
    f2z()
x=2
y=1
print(f1x())
from b.c.z import f2z
f2x()